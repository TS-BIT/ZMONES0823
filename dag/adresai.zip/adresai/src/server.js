import express from "express";
import exphbs from "express-handlebars";
import { deleteZmogus, getZmogus, getZmones, saveZmogus } from "./db.js";

const PORT = 3000;
const WEB_DIR = "web";

const app = express();
app.engine(
  "handlebars",
  exphbs({
    helpers: {
      dateFormat(d) {
        if (d instanceof Date) {
          let year = d.getFullYear();
          let month = d.getMonth() + 1;
          if (month < 10) {
            month = "0" + month;
          }
          let day = d.getDate();
          if (day < 10) {
            day = "0" + day;
          }
          return `${year}-${month}-${day}`;
        }
      },
    },
  }),
);
app.set("view engine", "handlebars");

app.use(express.static(WEB_DIR, {
  index: false,
}));
app.use(express.urlencoded({
  extended: true,
}));
app.use(express.json());

app.get("/", async (req, res) => {
  try {
    let zmones = await getZmones();

    res.render("zmones", {
      zmones,
      title: "Pilnas zmoniu sarasas",
    });
  } catch (err) {
    res.status(500).end(
      `<html><body>Ivyko klaida: ${err.message}</body></html>`,
    );
  }
});

app.get("/zmogus/:id?", async (req, res) => {
  try {
    let zmogus = null;
    if (req.params.id) {
      zmogus = await getZmogus(req.params.id);
    }

    res.render("zmogus", {
      zmogus,
      title: "Vienas zmogus",
    });
  } catch (err) {
    res.status(500).end(
      `<html><body>Ivyko klaida: ${err.message}</body></html>`,
    );
  }
});

app.post("/zmogus", async (req, res) => {
  try {
    await saveZmogus(req.body);

    res.redirect("/");
  } catch (err) {
    res.status(500).end(
      `<html><body>Ivyko klaida: ${err.message}</body></html>`,
    );
  }
});

app.get("/zmogus/:id/delete", async (req, res) => {
  try {
    await deleteZmogus(req.params.id);

    res.redirect("/");
  } catch (err) {
    res.status(500).end(
      `<html><body>Ivyko klaida: ${err.message}</body></html>`,
    );
  }
});

app.get("/json/zmogus", async (req, res) => {
  try {
    let zmones = await getZmones();
    res.set("Content-Type", "application/json");
    res.send(JSON.stringify(zmones));
  } catch (err) {
    res.status(500).end(
      `<html><body>Ivyko klaida: ${err.message}</body></html>`,
    );
  }
});

app.get("/json/zmogus/:id", async (req, res) => {
  try {
    let zmogus = await getZmogus(req.params.id);
    res.set("Content-Type", "application/json");
    res.send(JSON.stringify(zmogus));
  } catch (err) {
    res.status(500).end(
      `<html><body>Ivyko klaida: ${err.message}</body></html>`,
    );
  }
});

app.delete("/json/zmogus/:id", async (req, res) => {
  try {
    await deleteZmogus(req.params.id);
    res.status(200).end();
  } catch (err) {
    res.status(500).end(
      `<html><body>Ivyko klaida: ${err.message}</body></html>`,
    );
  }
});

app.post("/json/zmogus", async (req, res) => {
  try {
    if (req.body.id) {
      delete req.body.id;
    }

    const zmogus = await saveZmogus(req.body);

    res.set("Content-Type", "application/json");
    res.send(JSON.stringify(zmogus));
  } catch (err) {
    res.status(500).end(
      `<html><body>Ivyko klaida: ${err.message}</body></html>`,
    );
  }
});

app.put("/json/zmogus/:id", async (req, res) => {
  try {

    req.body.id = req.params.id;

    const zmogus = await saveZmogus(req.body);
    res.set("Content-Type", "application/json");
    if (zmogus) {
      res.status(200).end(JSON.stringify(zmogus));
    } else {
      res.status(404).end();
    }

  } catch (err) {
    res.status(500).end(
      `<html><body>Ivyko klaida: ${err.message}</body></html>`,
    );
  }
});

app.listen(PORT);
console.log(`Server started on port ${PORT}`);
