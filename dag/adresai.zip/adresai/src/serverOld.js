import readline from "readline";
import mysql from "mysql";

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

function inputText(msg) {
  return new Promise((resolve) => {
    rl.question(msg, (answer) => {
      resolve(answer);
    });
  });
}
function inputNumber(msg) {
  return new Promise((resolve, reject) => {
    rl.question(msg, (answer) => {
      const num = parseFloat(answer);
      if (!isNaN(num) && Number.isFinite(num)) {
        resolve(num);
      } else {
        reject(new Error(`${answer} is not a number`));
      }
    });
  });
}

const conn = mysql.createConnection({
  host: "192.168.1.2",
  database: "adresu_knyga",
  user: "prog",
  password: "programos_pass",
});

function query(conn, sql, params) {
  return new Promise((resovle, reject) => {
    conn.query(sql, params, (err, results, fields) => {
      if (err) {
        return reject(err);
      }
      return resovle({
        results,
        fields,
      });
    });
  });
}

try {
    conn.connect();
    // const v = await inputText("Ivesk vardo dali: ");
    // const p = await inputText("Ivesk pavardes dali: ");
    // let { results: r, fields: f } = await query(
    //   conn,
    //   `select * from zmones where vardas like ? and pavarde like ?`,
    //   [`%${v}%`, `%${p}%`]
    // );

    // const v = await inputText("Ivesk varda: ");
    // const p = await inputText("Ivesk pavarde: ");
    // let { results: r, fields: f } = await query(
    //   conn,
    //   `insert into zmones (vardas, pavarde) values (?, ?)`,
    //   [v, p]
    // );

    // const id = await inputNumber("Ivesk id: ");
    // const v = await inputText("Ivesk varda: ");
    // const p = await inputText("Ivesk pavarde: ");
    // let { results: r, fields: f } = await query(
    //   conn,
    //   `update zmones set vardas = ?, pavarde = ? where id = ?`,
    //   [v, p, id]
    // );

    const id = await inputNumber("Ivesk id: ");
    let { results: r, fields: f } = await query(
      conn,
      `delete from zmones where id = ?`,
      [id]
    );

    console.log(f);
    console.log(r);
} catch (err) {
    console.log("Klaida: ", err);
} finally {
    conn.end();
    rl.close();
}

