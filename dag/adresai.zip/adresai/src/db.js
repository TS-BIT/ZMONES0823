import mysql from "mysql";

const options = {
  host: "192.168.1.2",
  database: "adresu_knyga",
  user: "prog",
  password: "programos_pass",
};

function query(conn, sql, params) {
  return new Promise((resovle, reject) => {
    conn.query(sql, params, (err, results, fields) => {
      if (err) {
        return reject(err);
      }
      return resovle({
        results,
        fields,
      });
    });
  });
}

async function getZmones() {
  let conn;
  try {
    conn = mysql.createConnection(options);
    conn.connect();
    let { results: r } = await query(
      conn,
      `select id, vardas, pavarde, gim_data as gimData, alga from zmones order by vardas, pavarde`,
    );
    return r;
  } finally {
    conn.end();
  }
}

async function getZmogus(id) {
  id = parseInt(id);
  if (!isFinite(id)) {
    return null;
  }
  let conn;
  try {
    conn = mysql.createConnection(options);
    conn.connect();
    let { results: r } = await query(
      conn,
      `select id, vardas, pavarde, gim_data as gimData, alga from zmones where id = ?`,
      [id],
    );
    if (r.length > 0) {
      return r[0];
    } else {
      return null;
    }
  } finally {
    conn.end();
  }
}

async function deleteZmogus(id) {
  id = parseInt(id);
  if (!isFinite(id)) {
    return;
  }
  let conn;
  try {
    conn = mysql.createConnection(options);
    conn.connect();
    await query(
      conn,
      `delete from zmones where id = ?`,
      [id],
    );
    return;
  } finally {
    conn.end();
  }
}

async function saveZmogus(zmogus) {
  if (typeof zmogus.id === "undefined") {
    let conn;
    try {
      conn = mysql.createConnection(options);
      conn.connect();
      const { results } = await query(
        conn,
        `insert into zmones (vardas, pavarde, gim_data, alga) values (?, ?, ?, ?)`,
        [zmogus.vardas, zmogus.pavarde, zmogus.gimData, zmogus.alga],
      );
      zmogus.id = results.nextId;
      return zmogus;
    } finally {
      conn.end();
    }
  } else {
    zmogus.id = parseInt(zmogus.id);
    if (!isFinite(zmogus.id)) {
      return;
    }
    let conn;
    try {
      conn = mysql.createConnection(options);
      conn.connect();
      const { results } = await query(
        conn,
        `update zmones set vardas = ?, pavarde = ?, gim_data = ?, alga = ? where id = ?`,
        [zmogus.vardas, zmogus.pavarde, zmogus.gimData, zmogus.alga, zmogus.id],
      );
      if (results.affectedRows) {
        return zmogus;
      } else {
        return null;
      }
    } finally {
      conn.end();
    }
  }
}

export { deleteZmogus, getZmogus, getZmones, saveZmogus };
