// cia saugom visa zmoniu sarasa
let zmones = [];

// Parodom sarasa zmoniu:
// isvalom elementa su id=app
// sukuriam nauja table elementa su zmoniu sarasu
// padedam table i elementa su id=app
function showZmones() {
    const app = document.getElementById("app");
    cleanElement(app);
    const table = document.createElement("table");
    for (const zmogus of zmones) {
        const tr = document.createElement("tr");
        let td;
        let a;
        td = document.createElement("td");
        a = document.createElement("a");
        a.appendChild(document.createTextNode(zmogus.vardas));
        a.zmogusId = zmogus.id;
        a.onclick = showZmogus;
        td.appendChild(a);
        tr.appendChild(td);
        td = document.createElement("td");
        a = document.createElement("a");
        a.appendChild(document.createTextNode(zmogus.pavarde));
        a.zmogusId = zmogus.id;
        a.onclick = showZmogus;
        td.appendChild(a);
        tr.appendChild(td);
        td = document.createElement("td");
        td.appendChild(document.createTextNode(zmogus.alga));
        tr.appendChild(td);
        td = document.createElement("td");
        const button = document.createElement("button");
        button.appendChild(document.createTextNode("X"));
        button.zmogusId = zmogus.id;
        button.onclick = deleteZmogus;
        td.appendChild(button);
        tr.appendChild(td);
        table.appendChild(tr);
    }
    app.appendChild(table);
}

// Parodoma zmogaus redagavimo forma elemente id=app
// jei elementas, kuris inicijavo sita parodyma, turi savybe zmogusId,
// tai ieskom tokio zmogaus sarase ir jo duomenis naudojam, kaip
// pradines reiksmes input elementam ir papildomai sukuriam input elementa
// su id=id
function showZmogus(event) {
    let zmogus;
    if (event && event.target && event.target.zmogusId) {
        zmogus = zmones.find(z => z.id === event.target.zmogusId);
    }
    const app = document.getElementById("app");
    cleanElement(app);
    let input;
    if (zmogus) {
        input = document.createElement("input");
        input.type = "hidden";
        input.id = "id";
        input.value = zmogus.id;
        app.appendChild(input);
    }
    app.appendChild(document.createTextNode("Vardas:"));
    input = document.createElement("input");
    input.id = "vardas";
    if (zmogus) {
        input.value = zmogus.vardas;
    }
    app.appendChild(input);
    app.appendChild(document.createElement("br"));
    app.appendChild(document.createTextNode("Pavarde:"));
    input = document.createElement("input");
    input.id = "pavarde";
    if (zmogus) {
        input.value = zmogus.pavarde;
    }
    app.appendChild(input);
    app.appendChild(document.createElement("br"));
    app.appendChild(document.createTextNode("Alga:"));
    input = document.createElement("input");
    input.id = "alga";
    if (zmogus) {
        input.value = zmogus.alga;
    }
    app.appendChild(input);
    app.appendChild(document.createElement("br"));
    let button;
    button = document.createElement("button");
    button.appendChild(document.createTextNode("Save"));
    button.onclick = saveZmogus;
    app.appendChild(button);
    button = document.createElement("button");
    button.appendChild(document.createTextNode("Back"));
    button.onclick = showZmones;
    app.appendChild(button);
}

// Zmoniu gavimas is serverio
async function getZmones() {
    try {
        const res = await fetch("/json/zmogus");
        if (res.ok) {
            zmones = await res.json();
            showZmones();
        } else {
            console.log(res.status, res.statusText);
            alert("Klaida gaunant duomenis is serverio:" + res.statusText);
        }
    } catch (err) {
        console.error(err);
    }
}

// Zmogaus duomenu nusiuntimas (irasymas) i serveri
// surenkam duomenis is input elementu ir sukuriam zmogaus objekta
// jei yra input su id=id, traktuojam, kad tai esamo zmogaus redagavimas
// jei nera input su id=id - tai naujo ivedimas
// gavus atgal is serverio:
// jei redagavimas - pakeiciam savo sarase objekta su atitinkamu id
// jei naujas - pridedam nauja zmogaus objekta prie saraso
async function saveZmogus() {
    let id;
    const idEl = document.getElementById("id");
    if (idEl) {
        id = idEl.value;
    }
    let vardas = document.getElementById("vardas").value;
    let pavarde = document.getElementById("pavarde").value;
    let alga = parseFloat(document.getElementById("alga").value);
    let zmogus = {
        vardas,
        pavarde,
        alga
    };
    if (id) {
        zmogus.id = id;
    }
    try {
        let res = await fetch("/json/zmogus" + (id ? "/" + zmogus.id : ""), {
            method: (id ? "PUT" : "POST"),
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(zmogus)
        });
        if (res.ok) {
            zmogus = await res.json();
            if (id) {
                const index = zmones.findIndex(z => z.id === zmogus.id);
                if (index >= 0) {
                    zmones[index] = zmogus;
                    // zmones.splice(index, 1, zmogus);
                }
            } else {
                zmones.push(zmogus);
            }
            showZmones();
        } else {
            console.log(res.status, res.statusText);
            alert("Klaida issaugant:" + res.statusText);
        }
    } catch (err) {
        console.log(err);
    }
}

// Trinam zmogu pagal id
// id imamas is eventa inicijavusio elemento savybes zmogusId
// jei serveris sekmingai istryne - pasalinam ta elementa is savo saraso
async function deleteZmogus(event) {
    if (event && event.target && event.target.zmogusId) {
        const index = zmones.findIndex(z => z.id === event.target.zmogusId);
        const zmogus = zmones[index];
        try {
            const res = await fetch("/json/zmogus/" + zmogus.id, {
                method: "DELETE"
            });
            if (res.ok) {
                zmones.splice(index, 1);
                showZmones();
            } else {
                console.log(res.status, res.statusText);
                alert("Klaida trinant:" + res.statusText);
            }
        } catch (err) {
            console.error(err);
        }
    }
}

// pagalbine funkcija, kuri isvalo visus paduoto elemento "vaikus"
function cleanElement(el) {
    if (el instanceof Element) {
        while (el.firstChild) {
            el.firstChild.remove();
        }
    }
}